# Entrega – Equipo A: Actores

Esta entrega implementa el módulo de **Actores** sobre el proyecto base del taller. Se conservaron las carpetas y los módulos de los demás equipos; los cambios de código se concentran en los archivos propios de Actores.

## Qué quedó implementado

### API (ASP.NET Core)
- `GET /api/actores?pagina=1&recordsPorPagina=10`: listado ordenado por nombre y paginado.
- `GET /api/actores/{id}`: consulta por identificador.
- `GET /api/actores/buscarPorNombre/{nombre}`: búsqueda parcial, máximo cinco resultados, para el autocompletado de Películas.
- `POST /api/actores`: crea el actor mediante `multipart/form-data`.
- `PUT /api/actores/{id}`: actualiza los datos; conserva la foto si no se envía una nueva y reemplaza la anterior si se adjunta otra.
- `DELETE /api/actores/{id}`: elimina el actor y su archivo de foto.
- Validaciones de nombre, fecha de nacimiento e imagen según la guía.
- Caché de salida con etiqueta `actores` en los GET de listado y detalle; invalidación después de crear, editar o eliminar.

### Frontend (React + TypeScript)
- Índice de actores con paginación, foto, nombre, fecha y acciones de editar/eliminar con confirmación.
- Formularios reales de creación y edición conectados al API.
- Vista previa de la foto y conservación de la foto actual al editar sin seleccionar otra.
- Envío de archivos mediante `FormData`.
- Presentación de errores de validación devueltos por el API.

## Archivos propios agregados o completados

API:
- `DTOs/ActorCreacionDTO.cs`
- `Utilidades/ActoresProfile.cs`
- `Controllers/ActoresController.cs`

Frontend:
- `src/features/actores/modelos/Actor.model.ts`
- `src/features/actores/utilidades/convertirActorAFormData.ts`
- Componentes de `src/features/actores/componentes/`

## Cómo ejecutar en tu computador

### 1. API

Abre una terminal en `Taller_Base_API/api_base` y ejecuta:

```bash
dotnet restore
dotnet ef migrations add ModeloInicial
dotnet ef database update
dotnet watch run --launch-profile https
```

La guía indica que la migración se crea localmente y no se entrega. Si ya creaste la migración para esta base de datos, no la vuelvas a crear; ejecuta solamente `dotnet ef database update` y luego `dotnet watch run --launch-profile https`.

Swagger queda disponible en la dirección HTTPS configurada en `Properties/launchSettings.json` (en el proyecto base: `https://localhost:7256/swagger`).

### 2. Frontend

Abre otra terminal en `Taller_Base_Frontend/frontend_base` y ejecuta:

```bash
npm install
npm run dev
```

El archivo `.env` del proyecto base apunta a `https://localhost:7256/api`. Si tu API usa otro puerto, actualiza `VITE_API_URL` para que coincida con el puerto HTTPS del API.

## Pruebas recomendadas

1. Crear un actor con nombre `tom`: debe responder 400 por la primera letra minúscula.
2. Crear un actor con fecha futura: debe responder 400.
3. Intentar cargar un PDF como foto: debe responder 400.
4. Crear un actor con una foto JPG o PNG: debe aparecer en el índice y guardarse bajo `wwwroot/actores`.
5. Editar sin seleccionar una foto nueva: la foto anterior debe conservarse.
6. Editar seleccionando otra foto: debe reemplazarse la imagen anterior.
7. Eliminar un actor: debe desaparecer del índice y borrarse su archivo de foto.
8. Consultar `/api/actores/buscarPorNombre/tom`: debe devolver hasta cinco coincidencias.
9. Crear al menos doce actores y revisar la paginación.

> Nota de verificación: el entorno en el que se preparó este ZIP no tenía instalado el SDK de .NET y no logró completar la descarga de dependencias de npm. Por eso debes ejecutar los comandos anteriores en tu computador para confirmar la compilación y probar la conexión con tu SQL Server/LocalDB.
