using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using api.DTOs;
using api.Entidades;
using api.Servicios;

namespace api.Controllers
{
    [Route("api/actores")]
    [ApiController]
    public class ActoresController : CustomBaseController
    {
        private const string cacheTag = "actores";
        private const string contenedor = "actores";
        private readonly ApplicationDbContext context;
        private readonly IMapper mapper;
        private readonly IOutputCacheStore outputCacheStore;
        private readonly IAlmacenadorArchivos almacenadorArchivos;

        public ActoresController(
            ApplicationDbContext context,
            IMapper mapper,
            IOutputCacheStore outputCacheStore,
            IAlmacenadorArchivos almacenadorArchivos)
            : base(context, mapper, outputCacheStore, cacheTag)
        {
            this.context = context;
            this.mapper = mapper;
            this.outputCacheStore = outputCacheStore;
            this.almacenadorArchivos = almacenadorArchivos;
        }

        // GET: api/actores?pagina=1&recordsPorPagina=10
        [HttpGet]
        [OutputCache(Tags = [cacheTag])]
        public async Task<List<ActorDTO>> Get([FromQuery] PaginacionDTO paginacion)
        {
            return await Get<Actor, ActorDTO>(paginacion, actor => actor.Nombre);
        }

        // GET: api/actores/5
        [HttpGet("{id:int}", Name = "ObtenerActorPorId")]
        [OutputCache(Tags = [cacheTag])]
        public async Task<ActionResult<ActorDTO>> Get(int id)
        {
            return await Get<Actor, ActorDTO>(id);
        }

        // GET: api/actores/buscarPorNombre/Tom
        // Lo consume el autocompletado de actores del módulo de Películas.
        [HttpGet("buscarPorNombre/{nombre}")]
        public async Task<List<ActorPeliculaDTO>> BuscarPorNombre(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
            {
                return [];
            }

            return await context.Actores
                .Where(actor => actor.Nombre.Contains(nombre))
                .OrderBy(actor => actor.Nombre)
                .Take(5)
                .ProjectTo<ActorPeliculaDTO>(mapper.ConfigurationProvider)
                .ToListAsync();
        }

        // POST: api/actores (multipart/form-data)
        [HttpPost]
        public async Task<IActionResult> Post([FromForm] ActorCreacionDTO actorCreacionDTO)
        {
            var actor = mapper.Map<Actor>(actorCreacionDTO);

            if (actorCreacionDTO.Foto is not null)
            {
                actor.Foto = await almacenadorArchivos.Almacenar(contenedor, actorCreacionDTO.Foto);
            }

            context.Actores.Add(actor);
            await context.SaveChangesAsync();
            await outputCacheStore.EvictByTagAsync(cacheTag, default);

            var actorDTO = mapper.Map<ActorDTO>(actor);
            return CreatedAtRoute("ObtenerActorPorId", new { id = actor.Id }, actorDTO);
        }

        // PUT: api/actores/5 (multipart/form-data)
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Put(int id, [FromForm] ActorCreacionDTO actorCreacionDTO)
        {
            var actorDB = await context.Actores.FirstOrDefaultAsync(actor => actor.Id == id);

            if (actorDB is null)
            {
                return NotFound();
            }

            // El mapeo ignora Foto: si no llega una imagen nueva, se conserva la actual.
            mapper.Map(actorCreacionDTO, actorDB);

            if (actorCreacionDTO.Foto is not null)
            {
                actorDB.Foto = await almacenadorArchivos.Editar(
                    actorDB.Foto, contenedor, actorCreacionDTO.Foto);
            }

            await context.SaveChangesAsync();
            await outputCacheStore.EvictByTagAsync(cacheTag, default);
            return NoContent();
        }

        // DELETE: api/actores/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var actor = await context.Actores.FirstOrDefaultAsync(actor => actor.Id == id);

            if (actor is null)
            {
                return NotFound();
            }

            var rutaFoto = actor.Foto;
            context.Actores.Remove(actor);
            await context.SaveChangesAsync();

            await almacenadorArchivos.Borrar(rutaFoto, contenedor);
            await outputCacheStore.EvictByTagAsync(cacheTag, default);
            return NoContent();
        }
    }
}
