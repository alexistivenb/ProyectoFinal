using AutoMapper;
using api.DTOs;
using api.Entidades;

namespace api.Utilidades
{
    public class ActoresProfile : Profile
    {
        public ActoresProfile()
        {
            // La foto se guarda como URL en Actor. El controlador recibe el archivo
            // y asigna esa URL después de almacenarlo.
            CreateMap<ActorCreacionDTO, Actor>()
                .ForMember(actor => actor.Foto, opciones => opciones.Ignore());
        }
    }
}
